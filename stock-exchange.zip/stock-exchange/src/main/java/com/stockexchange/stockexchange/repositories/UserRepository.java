package com.stockexchange.stockexchange.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.stockexchange.stockexchange.models.User;


public interface UserRepository extends JpaRepository<User, Long> {

}
