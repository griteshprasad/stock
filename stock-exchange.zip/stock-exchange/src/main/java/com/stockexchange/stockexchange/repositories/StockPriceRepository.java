package com.stockexchange.stockexchange.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.stockexchange.stockexchange.models.StockPrice;



public interface StockPriceRepository extends JpaRepository<StockPrice, Long> {

}
