package com.stockexchange.stockexchange.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.stockexchange.stockexchange.models.StockExchange;



public interface StockExchangeRepository extends JpaRepository<StockExchange, Long> {

}
