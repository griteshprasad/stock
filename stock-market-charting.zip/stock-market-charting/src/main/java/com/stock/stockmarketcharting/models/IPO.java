package com.stock.stockmarketcharting.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class IPO {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long ipo_id;
	
	private String company_name;
	private StockExchange stock_exchange;
	private double price_per_share;
	private int total_shares;
	private String open_date_time;
	private String remarks;

	public Long getIpo_id() {
		return ipo_id;
	}

	public void setIpo_id(Long ipo_id) {
		this.ipo_id = ipo_id;
	}

	public String getCompany_name() {
		return company_name;
	}

	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}

	public StockExchange getStock_exchange() {
		return stock_exchange;
	}

	public void setStock_exchange(StockExchange stock_exchange) {
		this.stock_exchange = stock_exchange;
	}

	public double getPrice_per_share() {
		return price_per_share;
	}

	public void setPrice_per_share(double price_per_share) {
		this.price_per_share = price_per_share;
	}

	public int getTotal_shares() {
		return total_shares;
	}

	public void setTotal_shares(int total_shares) {
		this.total_shares = total_shares;
	}

	public String getOpen_date_time() {
		return open_date_time;
	}

	public void setOpen_date_time(String open_date_time) {
		this.open_date_time = open_date_time;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
}
