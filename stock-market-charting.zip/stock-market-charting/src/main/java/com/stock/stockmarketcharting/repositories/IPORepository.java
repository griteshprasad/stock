package com.stock.stockmarketcharting.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.stock.stockmarketcharting.models.IPO;

public interface IPORepository extends JpaRepository<IPO, Long> {

}
