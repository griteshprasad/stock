package com.stock.stockmarketcharting.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class StockPrice {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long stock_price_id;
	
	private Long company_code;
	private Long stock_exchange_id;
	private double current_price;
	private String date;
	private String time;

	public Long getStock_price_id() {
		return stock_price_id;
	}

	public void setStock_price_id(Long stock_price_id) {
		this.stock_price_id = stock_price_id;
	}

	public Long getCompany_code() {
		return company_code;
	}

	public void setCompany_code(Long company_code) {
		this.company_code = company_code;
	}


	public Long getStock_exchange_id() {
		return stock_exchange_id;
	}

	public void setStock_exchange_id(Long stock_exchange_id) {
		this.stock_exchange_id = stock_exchange_id;
	}

	public double getCurrent_price() {
		return current_price;
	}

	public void setCurrent_price(double current_price) {
		this.current_price = current_price;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}
}
