package com.stock.stockmarketcharting.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Sector {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long sector_id;
	
	private String sector_name;
	private String brief;

	public Long getSector_id() {
		return sector_id;
	}

	public void setSector_id(Long sector_id) {
		this.sector_id = sector_id;
	}

	public String getSector_name() {
		return sector_name;
	}

	public void setSector_name(String sector_name) {
		this.sector_name = sector_name;
	}

	public String getBrief() {
		return brief;
	}

	public void setBrief(String brief) {
		this.brief = brief;
	}

}
