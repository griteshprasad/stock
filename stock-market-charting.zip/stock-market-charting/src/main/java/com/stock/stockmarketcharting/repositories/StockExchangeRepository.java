package com.stock.stockmarketcharting.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.stock.stockmarketcharting.models.StockExchange;

public interface StockExchangeRepository extends JpaRepository<StockExchange, Long> {

}
